/**
 * 
 */
/**
 * 
 */
module MyFirstGame {
	requires java.desktop;
}