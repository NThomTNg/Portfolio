package Main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

import Entity.Player;
import tile.TileManager;

public class GamePanel extends JPanel implements Runnable {
    
    // Screen settings
    final int originalTileSize = 16; // 16x16 pixels per tile
    final int scale = 3;
    public final int tileSize = originalTileSize * scale; // 48x48 tiles for larger screens
    public final int maxScreenCol = 18;
    public final int maxScreenRow = 14;
    public final int screenWidth = tileSize * maxScreenCol; 
    public final int screenHeight = tileSize * maxScreenRow;
    
    // World Settings
    public final int maxWorldCol = 50;
    public final int maxWorldRow = 50;
    public final int maxWorldWidth = tileSize * maxWorldCol;
    public final int maxWorldHeight = tileSize * maxWorldRow;
    
    // Game loop settings
    int FPS = 60;
    double drawInterval = 1000000000.0 / FPS; // Each frame duration in nanoseconds
    
    // Game Components
    TileManager tileM = new TileManager(this);
    KeyHandler keyH = new KeyHandler();
    Thread gameThread;
    public CollisionChecker cChecker = new CollisionChecker(this);
    public Player player = new Player(this, keyH);

    // Player settings
    int playerX = 100;
    int playerY = 100;
    int playerSpeed = 4;

    // Constructor for initializing panel settings
    public GamePanel() {
        setupPanel();
        initializeListeners();
    }

    private void setupPanel() {
        this.setPreferredSize(new Dimension(screenWidth, screenHeight));
        this.setBackground(Color.black);
        this.setDoubleBuffered(true);
        this.setFocusable(true);
    }

    private void initializeListeners() {
        this.addKeyListener(keyH);
    }

    // Start game loop in a new thread
    public void startGameThread() {
        gameThread = new Thread(this);
        gameThread.start();
    }

    @Override
    public void run() {
        double nextDrawTime = System.nanoTime() + drawInterval;

        while (gameThread != null) {
            updateGame();
            repaint();
            manageFrameTiming(nextDrawTime);
            nextDrawTime += drawInterval;
        }
    }

    // Update game elements
    public void updateGame() {
        player.update();
    }

    // Handle frame timing to maintain consistent FPS
    private void manageFrameTiming(double nextDrawTime) {
        try {
            double remainingTime = (nextDrawTime - System.nanoTime()) / 1000000.0; // Convert to milliseconds
            if (remainingTime > 0) {
                Thread.sleep((long) remainingTime);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        render((Graphics2D) g);
    }

    // Render tiles and player on the screen
    private void render(Graphics2D g2) {
        tileM.draw(g2);
        player.draw(g2);
        g2.dispose();
    }
}
