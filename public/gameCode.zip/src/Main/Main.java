package Main;

import javax.swing.JFrame;

public class Main {
	public static void main(String[]args) {
		
		// Create and configure the main window
		JFrame window = new JFrame();
		GamePanel gamePanel = new GamePanel();
		
		window.setTitle("Adventure's of Yoren");
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		window.add(gamePanel);
		
		window.setResizable(false);
		window.setLocationRelativeTo(null);
		window.setVisible(true);
		
		window.pack();
		
		// Start the game loop
		gamePanel.startGameThread();
	}
}